/* ================= dIAgnostico — Lógica principal ================= */
(function(){
  'use strict';

  /* ---------- Estado ---------- */
  const state = {
    name: '',
    age: null,
    os: '',
    brand: '',
    level: 1,
    lang: 'es',
    voice: false,
    simple: false,
    fontSize: 18,
    apiKey: '',
    endpoint: '',
    model: '',
    lastTopic: null,
    awaitingSolved: false
  };

  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
  const T = (k) => (I18N[state.lang] && I18N[state.lang][k]) || I18N.es[k] || k;

  /* ---------- Persistencia local ---------- */
  const STORE_KEY = 'diagnostico.v1';
  function saveState(){
    try{ localStorage.setItem(STORE_KEY, JSON.stringify(state)); }catch(e){}
  }
  function loadState(){
    try{
      const raw = localStorage.getItem(STORE_KEY);
      if(raw) Object.assign(state, JSON.parse(raw));
    }catch(e){}
  }

  /* ---------- Pantallas ---------- */
  function showScreen(id){
    $$('.screen').forEach(s => s.classList.remove('active'));
    $('#' + id).classList.add('active');
    window.scrollTo(0,0);
  }

  /* ---------- Aplicar idioma ---------- */
  function applyLang(code){
    state.lang = I18N[code] ? code : 'es';
    document.documentElement.lang = state.lang;
    document.documentElement.dir = (state.lang === 'ar') ? 'rtl' : 'ltr';
    $$('[data-i18n]').forEach(el => {
      const k = el.getAttribute('data-i18n');
      const v = T(k);
      if(v) el.textContent = v;
    });
    $$('[data-i18n-ph]').forEach(el => {
      const k = el.getAttribute('data-i18n-ph');
      const v = T(k);
      if(v) el.setAttribute('placeholder', v);
    });
    $('#sel-lang').value = state.lang;
    const sl2 = $('#set-lang2');
    if(sl2){
      sl2.innerHTML = '';
      Object.keys(I18N).forEach(c => {
        const o = document.createElement('option');
        o.value = c;
        o.textContent = LANG_NAMES[c] || c;
        sl2.appendChild(o);
      });
      sl2.value = state.lang;
    }
    saveState();
  }

  const LANG_NAMES = {
    es:'Español', en:'English', pt:'Português', fr:'Français', it:'Italiano',
    de:'Deutsch', zh:'中文', ja:'日本語', ko:'한국어', ru:'Русский', ar:'العربية', hi:'हिन्दी'
  };

  /* ---------- Aplicar tamaño de letra ---------- */
  function applyFontSize(px){
    state.fontSize = px;
    document.documentElement.style.setProperty('--font-size', px + 'px');
    $('#set-size').value = px;
    saveState();
  }

  /* ---------- Voz ---------- */
  let voices = [];
  function loadVoices(){ voices = window.speechSynthesis ? speechSynthesis.getVoices() : []; }
  if(window.speechSynthesis){
    loadVoices();
    speechSynthesis.onvoiceschanged = loadVoices;
  }
  function speak(text){
    if(!state.voice || !window.speechSynthesis || !text) return;
    try{
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text.replace(/[•→⚠️]/g,'').slice(0,1200));
      const code = SPEECH_LANG[state.lang] || 'es-ES';
      u.lang = code;
      const v = voices.find(x => x.lang === code) || voices.find(x => x.lang && x.lang.startsWith(code.slice(0,2)));
      if(v) u.voice = v;
      u.rate = 0.95;
      u.pitch = 1;
      speechSynthesis.speak(u);
    }catch(e){}
  }

  /* ---------- Render de mensajes ---------- */
  const chatBody = () => $('#chat-body');

  function scrollBottom(){
    const b = chatBody();
    requestAnimationFrame(() => { b.scrollTop = b.scrollHeight; });
  }

  function addUser(text){
    const wrap = document.createElement('div');
    wrap.className = 'msg user';
    const bub = document.createElement('div');
    bub.className = 'bubble';
    bub.textContent = text;
    wrap.appendChild(bub);
    chatBody().appendChild(wrap);
    scrollBottom();
  }

  function botBubble(){
    const wrap = document.createElement('div');
    wrap.className = 'msg bot';
    const av = document.createElement('div');
    av.className = 'bot-avatar';
    av.textContent = 'IA';
    const bub = document.createElement('div');
    bub.className = 'bubble';
    wrap.appendChild(av);
    wrap.appendChild(bub);
    chatBody().appendChild(wrap);
    scrollBottom();
    return bub;
  }

  function addBot(html, plainForSpeech){
    const bub = botBubble();
    bub.innerHTML = html;
    scrollBottom();
    if(plainForSpeech) speak(plainForSpeech);
    return bub;
  }

  function addTyping(){
    const wrap = document.createElement('div');
    wrap.className = 'msg bot';
    wrap.id = 'typing-msg';
    const av = document.createElement('div');
    av.className = 'bot-avatar'; av.textContent = 'IA';
    const bub = document.createElement('div');
    bub.className = 'bubble';
    bub.innerHTML = '<div class="typing"><span></span><span></span><span></span></div>';
    wrap.appendChild(av); wrap.appendChild(bub);
    chatBody().appendChild(wrap);
    scrollBottom();
  }
  function removeTyping(){
    const t = $('#typing-msg');
    if(t) t.remove();
  }

  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  /* ---------- Chips de opciones ---------- */
  function addChips(options, onPick){
    const bub = botBubble();
    const box = document.createElement('div');
    box.className = 'chips';
    options.forEach(o => {
      const b = document.createElement('button');
      b.className = 'chip';
      b.type = 'button';
      b.textContent = o.label;
      b.addEventListener('click', () => {
        box.remove();
        onPick(o);
      });
      box.appendChild(b);
    });
    bub.appendChild(box);
    scrollBottom();
  }

  /* ---------- Adaptación al nivel ---------- */
  function adaptText(text, step){
    let out = text;
    if(state.level === 0){
      // Añade aclaración en pasos muy técnicos
      if(/administrador|terminal|comando|controlador|BIOS|registro/i.test(out) && !/muy fácil|sencillo/i.test(out)){
        out += ' (No te preocupes si no entiendes estas palabras: hazlo tal cual y saldrá bien.)';
      }
    }
    if(state.level === 3 && step && step.adv){
      out += ' ' + step.adv;
    }
    return out;
  }

  /* ---------- Búsqueda en base de conocimiento ---------- */
  function normalize(s){
    return String(s||'').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  }

  function searchKB(text){
    const q = normalize(text);
    if(!q.trim()) return null;
    let best = null, bestScore = 0;
    KB.forEach(topic => {
      let score = 0;
      topic.tags.forEach(tag => {
        const nt = normalize(tag);
        if(q.includes(nt)) score += nt.length > 6 ? 3 : 2;
        else if(nt.includes(q) && q.length > 4) score += 1;
      });
      if(score > bestScore){ bestScore = score; best = topic; }
    });
    return bestScore >= 2 ? best : null;
  }

  /* ---------- Construir respuesta de pasos ---------- */
  function buildStepsHTML(topic){
    const osKey = (state.os === 'apple' || state.os === 'linux' || state.os === 'windows') ? state.os : 'windows';
    const steps = (topic.pasos && topic.pasos[osKey]) || topic.pasos.windows || [];
    let html = '';
    html += '<p>' + esc(topic.acuse) + '</p>';

    if(topic.preguntas && topic.preguntas.length){
      html += '<div class="q-box">' + topic.preguntas.map(p => '👉 ' + esc(p)).join('<br>') + '</div>';
    }

    html += '<h4 style="margin-top:14px">' + esc(T('steps')) + '</h4>';
    html += '<ol class="steps">';
    steps.forEach((s, i) => {
      html += '<li>';
      html += '<span class="step-t">' + esc(s.t) + '</span>';
      if(s.d) html += '<span class="step-d">' + esc(adaptText(s.d, s)) + '</span>';
      html += '</li>';
    });
    html += '</ol>';

    if(state.level === 0 && topic.detalle){
      html += '<p style="margin-top:12px;font-size:.88em;color:var(--ink-soft)">' + esc(topic.detalle) + '</p>';
    }

    if(topic.peligro){
      html += '<div class="warn-box">' + esc(T('danger')) + '</div>';
    }

    if(state.brand){
      html += '<div class="q-box" style="margin-top:12px">' + esc(T('brand_tip')) + ' <strong>' + esc(state.brand) + '</strong>: ' +
              'los menús pueden verse un poco distintos, pero los nombres son los mismos.</div>';
    }

    return html;
  }

  function speechFromTopic(topic){
    const osKey = (state.os === 'apple' || state.os === 'linux' || state.os === 'windows') ? state.os : 'windows';
    const steps = (topic.pasos && topic.pasos[osKey]) || [];
    return topic.acuse + ' ' + steps.map((s,i) => (i+1) + '. ' + s.t).join(' ');
  }

  /* ---------- Motor de IA opcional ---------- */
  async function askAI(userText){
    const endpoint = state.endpoint || 'https://api.openai.com/v1/chat/completions';
    const model = state.model || 'gpt-4o-mini';
    const levelDesc = ['Nada de tecnología: usa palabras muy simples y analogías','Uso básico','Conocimiento medio: puede seguir pasos técnicos','Avanzado: puede usar terminal'];
    const sys = [
      'Eres dIAgnostico, un asistente técnico amable y paciente que ayuda a personas de todas las edades a resolver problemas de computadoras.',
      'Responde SIEMPRE en el idioma del usuario (' + state.lang + ').',
      'Da instrucciones paso a paso, numeradas, cortas y claras.',
      'Usuario: ' + (state.name||'') + ', ' + (state.age||'') + ' años, sistema ' + (state.os||'desconocido') + ', marca ' + (state.brand||'desconocida') + '.',
      'Nivel técnico: ' + levelDesc[state.level] + '.',
      'Si un paso puede ser peligroso, adviértelo. No inventes rutas que no existan.'
    ].join(' ');

    const res = await fetch(endpoint, {
      method:'POST',
      headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer ' + state.apiKey },
      body: JSON.stringify({
        model,
        messages:[ {role:'system',content:sys}, {role:'user',content:userText} ],
        temperature:0.4
      })
    });
    if(!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    return (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
  }

  /* ---------- Flujo: pregunta del usuario ---------- */
  async function handleUserInput(text){
    if(!text.trim()) return;
    addUser(text);
    $('#inp-msg').value = '';
    $('#inp-msg').style.height = 'auto';

    const detected = detectLang(text);
    if(detected && detected !== state.lang){
      applyLang(detected);
    }

    addTyping();
    await wait(280);
    removeTyping();

    const topic = searchKB(text);
    if(topic){
      state.lastTopic = topic;
      const html = buildStepsHTML(topic);
      addBot(html, speechFromTopic(topic));
      state.awaitingSolved = true;
      addChips([
        {label: T('yes'), value:'__solved'},
        {label: T('no'), value:'__notsolved'},
        {label: T('other'), value:'__other'}
      ], (o) => {
        if(o.value === '__solved'){ onSolved(); }
        else if(o.value === '__notsolved'){ onNotSolved(); }
        else { promptOther(); }
      });
      setQuickReplies();
      return;
    }

    if(state.apiKey){
      addTyping();
      try{
        const answer = await askAI(text);
        removeTyping();
        if(answer){
          addBot('<p>' + esc(answer).replace(/\n/g,'<br>') + '</p>', answer);
          return;
        }
      }catch(e){
        removeTyping();
        addBot('<p>' + esc(T('ai_fail')) + '</p>');
      }
    }

    const html = buildStepsHTML(FALLBACK);
    addBot('<p>' + esc(T('search_notfound')) + '</p>' + html, FALLBACK.acuse);
  }

  function onSolved(){
    addBot('<p>' + esc(T('solved_msg')) + '</p>', T('solved_msg'));
    state.awaitingSolved = false;
    setQuickReplies();
  }
  function onNotSolved(){
    addBot('<p>' + esc(T('ask_more')) + '</p>', T('ask_more'));
    setQuickReplies();
  }
  function promptOther(){
    setQuickReplies();
    $('#inp-msg').focus();
  }

  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  /* ---------- Respuestas rápidas inferiores ---------- */
  function setQuickReplies(){
    const qr = $('#quick-replies');
    qr.innerHTML = '';
    const keys = ['no enciende','lento','internet','pantalla azul','sonido','impresora','virus','actualizacion'];
    keys.forEach(k => {
      const topic = KB.find(t => t.tags.includes(k));
      const label = topic ? (EXAMPLES[k] || topic.title) : k;
      const b = document.createElement('button');
      b.className = 'chip';
      b.type = 'button';
      b.textContent = label;
      b.addEventListener('click', () => handleUserInput(k));
      qr.appendChild(b);
    });
  }

  /* ---------- Inicio de la conversación ---------- */
  function startChat(){
    showScreen('screen-chat');
    $('#user-chip').textContent = state.name + (state.age ? ', ' + state.age : '') + ' · ' + osLabel(state.os);

    chatBody().innerHTML = '';

    const hi = T('greet') + (state.name ? ', ' + state.name : '') + ' 👋';
    addBot('<p><strong>' + esc(hi) + '</strong></p><p>' + esc(T('greet2')) + '</p>', hi + '. ' + T('greet2'));

    if(!state.os || state.os === 'unknown'){
      addBot('<p>' + esc(T('what_os')) + '</p>');
      addChips([
        {label:'Windows', value:'windows'},
        {label:'Mac / Apple', value:'apple'},
        {label:'Linux', value:'linux'},
        {label:T('os_dontknow'), value:'unknown'}
      ], (o) => { state.os = o.value; saveState(); askMainProblem(); });
    }else{
      askMainProblem();
    }
  }

  function askMainProblem(){
    setTimeout(() => {
      addBot('<p>' + esc(T('how_feel')) + '</p>');
      const picks = ['no enciende','lento','internet','pantalla azul','sonido','impresora','virus','actualizacion'];
      addChips(picks.map(k => ({ label: EXAMPLES[k] || k, value:k })), (o) => handleUserInput(o.value));
      setQuickReplies();
    }, 420);
  }

  function osLabel(os){
    return { windows:'Windows', apple:'Mac / Apple', linux:'Linux', unknown:'?' }[os] || '?';
  }

  /* ---------- Selección en el formulario ---------- */
  function bindSelector(containerSel, attr, onPick){
    const box = $(containerSel);
    box.addEventListener('click', (e) => {
      const card = e.target.closest('[' + attr + ']');
      if(!card) return;
      $$('[' + attr + ']', box).forEach(c => c.setAttribute('aria-checked','false'));
      card.setAttribute('aria-checked','true');
      onPick(card.getAttribute(attr));
    });
  }

  /* ---------- Arranque ---------- */
  function init(){
    loadState();

    bindSelector('#os-grid', 'data-os', v => { state.os = v; saveState(); });
    bindSelector('#level-grid', 'data-level', v => { state.level = parseInt(v,10); saveState(); });

    // restaurar selección previa
    if(state.os){
      const el = $('[data-os="' + state.os + '"]');
      if(el) el.setAttribute('aria-checked','true');
    }
    const lvl = $('[data-level="' + (state.level!=null?state.level:1) + '"]');
    if(lvl) lvl.setAttribute('aria-checked','true');

    if(state.name) $('#inp-name').value = state.name;
    if(state.age) $('#inp-age').value = state.age;
    if(state.brand) $('#sel-brand').value = state.brand;

    applyLang(state.lang || 'es');
    applyFontSize(state.fontSize || 18);
    $('#set-voice').checked = !!state.voice;
    $('#set-simple').checked = !!state.simple;
    $('#set-key').value = state.apiKey || '';
    $('#set-endpoint').value = state.endpoint || '';
    $('#set-model').value = state.model || '';

    // auto-detect OS del navegador
    if(!state.os){
      const ua = navigator.userAgent;
      if(/Mac|iPhone|iPad/.test(ua)) state.os = 'apple';
      else if(/Linux|X11/.test(ua) && !/Android/.test(ua)) state.os = 'linux';
      else if(/Windows/.test(ua)) state.os = 'windows';
      if(state.os){
        const el = $('[data-os="' + state.os + '"]');
        if(el) el.setAttribute('aria-checked','true');
      }
      if(!state.level && state.level !== 0) state.level = 1;
    }

    // Formulario
    $('#profile-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const name = $('#inp-name').value.trim();
      const age = parseInt($('#inp-age').value, 10);
      if(!name){ $('#inp-name').focus(); return; }
      if(!age || age < 5 || age > 120){ $('#inp-age').focus(); return; }

      state.name = name;
      state.age = age;
      state.brand = $('#sel-brand').value;
      state.lang = $('#sel-lang').value;
      if(state.size === undefined) state.fontSize = age >= 60 ? 21 : 18;
      if(!localStorage.getItem(STORE_KEY + '.sized')){
        state.fontSize = age >= 60 ? 21 : 18;
        localStorage.setItem(STORE_KEY + '.sized','1');
      }
      applyLang(state.lang);
      applyFontSize(state.fontSize);
      saveState();
      startChat();
    });

    // Cambio de idioma en el formulario
    $('#sel-lang').addEventListener('change', (e) => {
      applyLang(e.target.value);
    });

    // Enviar mensaje
    const send = () => handleUserInput($('#inp-msg').value);
    $('#btn-send').addEventListener('click', send);
    $('#inp-msg').addEventListener('keydown', (e) => {
      if(e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); send(); }
    });
    $('#inp-msg').addEventListener('input', (e) => {
      e.target.style.height = 'auto';
      e.target.style.height = Math.min(e.target.scrollHeight, 140) + 'px';
    });

    // Volver
    $('#btn-back').addEventListener('click', () => {
      if(window.speechSynthesis) speechSynthesis.cancel();
      showScreen('screen-welcome');
    });

    // Voz
    $('#btn-voice').addEventListener('click', () => {
      state.voice = !state.voice;
      $('#btn-voice').setAttribute('aria-pressed', String(state.voice));
      $('#set-voice').checked = state.voice;
      if(!state.voice && window.speechSynthesis) speechSynthesis.cancel();
      saveState();
    });

    // A+
    $('#btn-bigger').addEventListener('click', () => {
      const next = state.fontSize >= 26 ? 16 : state.fontSize + 2;
      applyFontSize(next);
    });

    // Ajustes
    const modal = $('#modal-settings');
    const openModal = () => { modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); };
    const closeModal = () => { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); };
    $('#btn-settings').addEventListener('click', openModal);
    $('#btn-close-settings').addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => { if(e.target === modal) closeModal(); });

    $('#set-size').addEventListener('input', (e) => applyFontSize(parseInt(e.target.value,10)));
    $('#set-voice').addEventListener('change', (e) => {
      state.voice = e.target.checked;
      $('#btn-voice').setAttribute('aria-pressed', String(state.voice));
      saveState();
    });
    $('#set-simple').addEventListener('change', (e) => {
      state.simple = e.target.checked;
      if(state.simple) state.level = 0;
      saveState();
    });
    $('#set-lang2').addEventListener('change', (e) => {
      applyLang(e.target.value);
      $('#user-chip').textContent = state.name + (state.age ? ', ' + state.age : '') + ' · ' + osLabel(state.os);
      setQuickReplies();
    });
    $('#btn-save-settings').addEventListener('click', () => {
      state.apiKey = $('#set-key').value.trim();
      state.endpoint = $('#set-endpoint').value.trim();
      state.model = $('#set-model').value.trim();
      saveState();
      closeModal();
    });

    // Micrófono
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    $('#btn-mic').addEventListener('click', () => {
      if(!SR){ alert(T('no_mic')); return; }
      try{
        const rec = new SR();
        rec.lang = SPEECH_LANG[state.lang] || 'es-ES';
        rec.interimResults = false;
        rec.maxAlternatives = 1;
        $('#btn-mic').style.background = 'var(--brand)';
        $('#btn-mic').style.color = '#fff';
        rec.onresult = (ev) => {
          const txt = ev.results[0][0].transcript;
          $('#inp-msg').value = txt;
          handleUserInput(txt);
        };
        rec.onerror = () => { alert(T('not_understood')); };
        rec.onend = () => {
          $('#btn-mic').style.background = '';
          $('#btn-mic').style.color = '';
        };
        rec.start();
      }catch(e){ alert(T('no_mic')); }
    });

    // Si ya hay perfil completo, ofrecer continuar
    if(state.name && state.age){
      $('#btn-start').innerHTML = '<span>Continuar como ' + esc(state.name) + '</span> →';
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
