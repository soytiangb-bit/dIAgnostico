# dIAgnostico

Asistente web para resolver problemas de computadoras paso a paso, pensado para gente de todas las edades (especialmente personas mayores y quienes no saben de tecnología).

## Cómo abrirla

1. Descomprimí el archivo `.zip`.
2. Hacé doble clic en `index.html`.
3. Se abre en tu navegador. Ya funciona, sin instalar nada.

## Cómo publicarla en internet (gratis)

### Opción A — Netlify Drop (la más fácil, 2 minutos)
1. Entrá a `app.netlify.com/drop`
2. Arrastrá la carpeta completa `diagnostico` a la página.
3. Te da un enlace público tipo `https://algo-random.netlify.app`. Listo.

### Opción B — GitHub Pages
1. Creá un repositorio nuevo en GitHub y subí los 4 archivos (`index.html`, `styles.css`, `app.js`, `kb.js`, `i18n.js`).
2. Settings → Pages → Branch: `main` → Save.
3. Tu página queda en `https://tuusuario.github.io/turepo/`.

### Opción C — Vercel
1. Entrá a `vercel.com`, importá la carpeta y desplegá.

## Qué incluye

- **Registro de perfil:** nombre, edad, sistema operativo, marca del equipo y nivel de conocimiento (4 niveles).
- **19 temas técnicos** resueltos paso a paso, con instrucciones distintas para **Windows, Linux y Apple**:
  no enciende, lentitud, internet/wifi, pantalla azul, pantalla negra, sonido, impresora, actualizaciones trabadas, contraseñas, virus, disco lleno, sobrecalentamiento, USB, batería, micrófono/cámara, correo, archivos borrados, teclado y wifi inestable.
- **12 idiomas:** español, inglés, portugués, francés, italiano, alemán, chino, japonés, coreano, ruso, árabe e hindi. Cambia solo si le escribís en otro idioma.
- **Accesibilidad:** letra grande ajustable, modo muy simple, lectura en voz alta y dictado por micrófono.
- **Avisos de seguridad** en los temas que pueden ser peligrosos.

## Motor de IA opcional (para preguntas libres)

La app funciona 100% sin internet usando su base de conocimiento. Si querés que además responda **cualquier** pregunta, abrí el engranaje ⚙ y pegá:

- **API Key:** tu clave (por ejemplo de OpenAI).
- **Endpoint:** `https://api.openai.com/v1/chat/completions`
- **Modelo:** `gpt-4o-mini` (o el que quieras)

> Importante: la clave se guarda solo en tu navegador. No la subas a un repositorio público. Si la página es pública, cualquier persona podría usar tu clave; para un uso serio conviene poner un pequeño servidor que guarde la clave del lado del servidor.

## Archivos

| Archivo | Qué hace |
|---|---|
| `index.html` | Estructura de la página |
| `styles.css` | Diseño y accesibilidad |
| `kb.js` | Base de conocimiento técnico (19 temas) |
| `i18n.js` | Textos en 12 idiomas y detección de idioma |
| `app.js` | Lógica del chat, perfil y voz |
