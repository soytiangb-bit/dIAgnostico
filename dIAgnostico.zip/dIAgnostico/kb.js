/* dIAgnostico — Base de conocimiento técnico
 * Cada tema tiene: id, etiquetas (ES/EN), y pasos por sistema operativo.
 * Los pasos se adaptan al nivel del usuario al mostrarse, pero el texto
 * base está redactado en lenguaje claro.
 */

const EXAMPLES = {
  "no enciende": "No enciende",
  "lento": "Va muy lenta",
  "internet": "Sin internet",
  "pantalla azul": "Pantalla azul",
  "pantalla negra": "Pantalla negra",
  "sonido": "No hay sonido",
  "impresora": "No imprime",
  "actualizacion": "Actualización trabada",
  "contrasena": "Olvidé mi contraseña",
  "virus": "Tengo un virus",
  "lleno": "Disco lleno",
  "calor": "Se calienta mucho",
  "usb": "No lee la USB",
  "bateria": "Batería no carga",
  "microfono": "No funciona el micrófono",
  "webcam": "No se ve la cámara",
  "correo": "No entra al correo",
  "archivo perdido": "Borré un archivo",
  "teclado": "Teclado falla",
  "wifi cae": "El wifi se corta"
};

const KB = [];

function T(id, tags, title, data){ KB.push({id, tags, title, ...data}); }

/* ---------------- 1. NO ENCIENDE ---------------- */
T("no_enciende", [
  "no enciende","no prende","no da imagen","no da señal","no arranca","muerta","no boot","won't turn on","no power","no enciende la pc"
], "La computadora no enciende", {
  acuse: "Vamos a revisar esto con calma. Casi siempre el problema está en la energía, no en la computadora.",
  preguntas: ["¿Tiene algún foquito encendido o se escucha algún ruido al apretar el botón?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Revisa que el cable de corriente esté bien conectado en la computadora y en el enchufe.", d:"Empújalo hasta el fondo. A veces queda suelto medio milímetro."},
      {t:"Si es una laptop, conecta el cargador y revisa el foquito del cargador.", d:"Si el foquito no prende, el problema puede ser el cargador, el cable o el enchufe. Prueba en otro enchufe."},
      {t:"Mantén apretado el botón de encendido 10 segundos y suéltalo.", d:"Esto apaga la computadora del todo cuando quedó 'trabada'. Después espera 5 segundos y vuelve a apretarlo normal."},
      {t:"Si es de escritorio, revisa que el cable del monitor esté conectado a la torre y a la pantalla.", d:"Fíjate que esté en la salida de video correcta. Si no estás seguro, prueba todas las salidas."},
      {t:"Quita cualquier memoria USB, disco externo o CD, y prueba encender de nuevo.", d:"A veces la computadora intenta arrancar desde un USB y se queda pensando."},
      {t:"Si es laptop, quita la batería si es de las que se pueden sacar, conecta solo el cargador y prueba encender.", d:"Si así enciende, la batería está fallando."},
      {t:"Si no prende nada, no fuerces más: puede ser la fuente de energía y conviene revisión técnica.", d:"No abras la fuente de poder. Dentro hay corriente peligrosa aunque esté desenchufada."}
    ],
    apple: [
      {t:"Conecta el cargador y espera 5 minutos. Las Mac necesitan algo de carga para arrancar.", d:"Revisa que el conector esté bien metido y que el foquito del cargador cambie de color."},
      {t:"Mantén apretado el botón de encendido 10 segundos y suéltalo.", d:"Luego espera 5 segundos y apriétalo de nuevo, normal."},
      {t:"Si es una Mac de escritorio (iMac, Mac mini), desconecta el cable de corriente, espera 30 segundos y vuelve a conectarlo.", d:"Esto reinicia el sistema de energía interno."},
      {t:"Prueba otro cable o cargador si tienes uno compatible.", d:"Muchas veces el problema es solo el cargador dañado."},
      {t:"Si es MacBook y no responde, prueba el reinicio de energía: apaga, mantén apretado el botón de encendido 10 segundos, y suelta.", d:"Si sigue sin dar señal, necesita revisión del servicio técnico autorizado."}
    ],
    linux: [
      {t:"Revisa el cable de corriente y el enchufe, igual que en cualquier equipo.", d:"Prueba en otro tomacorriente si puedes."},
      {t:"Mantén apretado el botón de encendido 10 segundos y vuelve a encender.", d:"Esto descarga la energía residual de la placa."},
      {t:"Si llega a la pantalla del logo pero no arranca el sistema, anota el mensaje que aparece.", d:"Ese mensaje nos dice qué está fallando. Si puedes, sácale una foto."},
      {t:"Desconecta periféricos (USB, discos externos) y prueba encender.", d:"Un dispositivo dañado puede impedir el arranque."},
      {t:"Si no da imagen en absoluto, el problema suele ser hardware (fuente o placa).", d:"Eso requiere revisión técnica; no es algo que se arregle por software."}
    ]
  }
});

/* ---------------- 2. LENTITUD ---------------- */
T("lento", [
  "lento","lenta","va lento","tarda mucho","se traba","congela","trabada","no responde","slow","lag","se cuelga"
], "La computadora va muy lenta", {
  acuse: "Esto tiene arreglo y casi nunca significa que la computadora esté vieja. Vamos por orden.",
  preguntas: ["¿Desde cuándo la notas lenta, y pasa siempre o solo con algunos programas?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Cierra las ventanas y programas que no estés usando.", d:"Cada pestaña del navegador consume memoria. Con 10 o 15 abiertas, la computadora se ahoga."},
      {t:"Reinicia la computadora de verdad, no solo la suspendas.", d:"Menú Inicio → botón de encendido → Reiniciar. Apagar y encender ya no es igual si usas el modo rápido."},
      {t:"Revisa el uso de memoria y procesador: aprieta Ctrl + Shift + Esc.", d:"Si la memoria está casi al 100%, ordena la lista por esa columna y cierra lo que más consume."},
      {t:"Desinstala programas que no uses hace meses.", d:"Configuración → Aplicaciones → Aplicaciones instaladas. Ordena por fecha de instalación."},
      {t:"Revisa el inicio automático: Configuración → Aplicaciones → Inicio.", d:"Desactiva lo que no necesites que abra al encender. Este paso es el que más se nota."},
      {t:"Busca actualizaciones del sistema pendientes.", d:"Configuración → Windows Update → Buscar actualizaciones."},
      {t:"Deja al menos 15% del disco libre.", d:"Si el disco está lleno, Windows no puede trabajar bien. Revisa Configuración → Sistema → Almacenamiento."},
      {t:"Si tiene disco mecánico (HDD) y sigue lenta, pasar a un disco SSD es la mejora más grande que existe.", d:"Ese cambio lo hace un técnico y suele rejuvenecer la computadora por completo."}
    ],
    apple: [
      {t:"Cierra las apps que no uses con Cmd + Q (no solo la ventana).", d:"Cerrar la ventana no cierra la app; sigue consumiendo memoria."},
      {t:"Reinicia la Mac desde el menú Apple → Reiniciar.", d:"Deja que se apague completamente antes de volver a encender."},
      {t:"Revisa el Monitor de Actividad: Aplicaciones → Utilidades → Monitor de Actividad.", d:"Ordena por % de CPU y por Memoria. Cierra lo que esté arriba y no estés usando."},
      {t:"Revisa las apps que abren al iniciar: Ajustes del Sistema → General → Ítems de inicio.", d:"Quita las que no necesites."},
      {t:"Libera espacio: menú Apple → Ajustes del Sistema → General → Almacenamiento.", d:"Las Mac necesitan al menos un 15% libre."},
      {t:"Actualiza el sistema: menú Apple → Ajustes del Sistema → General → Actualización de software.", d:"Los parches de rendimiento suelen ayudar."},
      {t:"Si es una Mac con disco lleno y muchos años, revisa el espacio y la salud del disco con Utilidad de Discos.", d:"Aplicaciones → Utilidades → Utilidad de Discos → botón 'Información'."}
    ],
    linux: [
      {t:"Revisa qué consume recursos con el Monitor del Sistema o con 'htop' en la terminal.", d:"Ordena por CPU y por memoria para ver los procesos más pesados."},
      {t:"Cierra aplicaciones que no uses y reinicia el equipo.", d:"Un reinicio limpio resuelve más de lo que parece."},
      {t:"Limpia la caché de paquetes: sudo apt clean (Debian/Ubuntu).", d:"Libera espacio que no se vuelve a usar."},
      {t:"Revisa el espacio libre con 'df -h'.", d:"Si la partición raíz está llena, el sistema se vuelve lentísimo."},
      {t:"Revisa los servicios que arrancan solos: 'systemctl list-unit-files --type=service --state=enabled'.", d:"Desactiva los que no necesites con sudo systemctl disable nombre."},
      {t:"Actualiza el sistema con tu gestor de paquetes (sudo apt update && sudo apt upgrade).", d:"Las actualizaciones incluyen mejoras de rendimiento."}
    ]
  }
});

/* ---------------- 3. INTERNET ---------------- */
T("internet", [
  "internet","wifi","wi-fi","no conecta","sin internet","no navega","red","router","se cae el internet","no wifi","conexion"
], "No tengo internet o no conecta al wifi", {
  acuse: "Vamos a separar dos cosas: si el wifi llega a la computadora, y si la computadora sale a internet.",
  preguntas: ["¿Otros aparatos (celular, otra compu) sí tienen internet en la misma casa?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Mira el icono de red abajo a la derecha, junto al reloj.", d:"Si tiene un globo terráqueo o un signo de admiración, no hay internet. Si tiene una señal con una x, el wifi está apagado."},
      {t:"Aprieta ese icono y revisa que el wifi esté activado y conectado a tu red.", d:"Si tu red no aparece, aleja la computadora del router o acércala un poco para probar."},
      {t:"Apaga el router 30 segundos y vuelve a prenderlo.", d:"Desenchúfalo de la corriente, cuenta hasta 30, y conéctalo. Espera 2 minutos a que levante."},
      {t:"Olvida la red y vuelve a conectarte con la contraseña.", d:"Configuración → Red e Internet → Wifi → Administrar redes conocidas → Olvidar."},
      {t:"Ejecuta el solucionador de problemas: Configuración → Sistema → Solucionar problemas → Otros solucionadores.", d:"Windows revisa y reinicia el adaptador de red automáticamente."},
      {t:"Si dice 'sin acceso a internet' pero el wifi está conectado, el problema puede ser del proveedor.", d:"Llama a tu compañía de internet y pregunta si hay una falla en tu zona."},
      {t:"Como último recurso, reinicia el adaptador: clic derecho en el icono de red → Solucionar problemas.", d:"Si sigue igual, anota el mensaje de error exacto para buscar la causa."}
    ],
    apple: [
      {t:"Mira el icono de wifi en la barra de arriba.", d:"Si está atenuado o con una exclamación, no hay conexión."},
      {t:"Abre el menú del wifi y elige tu red, escribiendo la contraseña de nuevo.", d:"Asegúrate de la mayúscula del principio y de que no haya espacios al final."},
      {t:"Apaga el router 30 segundos y vuelve a encenderlo.", d:"Desenchufa, espera 30 segundos, enchufa, y espera 2 minutos."},
      {t:"Reinicia la Mac desde el menú Apple → Reiniciar.", d:"Esto renueva la conexión de red."},
      {t:"Revisa Ajustes del Sistema → Red → Wifi y verifica que esté activado.", d:"Ahí puedes ver si está conectado y qué IP tiene."},
      {t:"Si otras personas de la casa tampoco tienen internet, es el proveedor.", d:"Comunícate con tu compañía de internet."}
    ],
    linux: [
      {t:"Revisa el icono de red en la esquina superior derecha.", d:"Si no ves ninguna red, el wifi puede estar bloqueado por hardware o software."},
      {t:"Verifica que el wifi no esté bloqueado: 'rfkill list'.", d:"Si aparece 'Soft blocked: yes', desbloquéalo con 'sudo rfkill unblock wifi'."},
      {t:"Reinicia el servicio de red: 'sudo systemctl restart NetworkManager'.", d:"En algunas distribuciones se llama 'network' o 'networking'."},
      {t:"Comprueba la conexión con 'ping 8.8.8.8'.", d:"Si responde pero no navegas, el problema es el DNS."},
      {t:"Si el DNS falla, prueba 'ping google.com'.", d:"Si 8.8.8.8 responde y google.com no, cambia el DNS a 8.8.8.8 en la configuración de red."},
      {t:"Apaga y enciende el router 30 segundos.", d:"Muchos problemas se resuelven solo con esto."}
    ]
  }
});

/* ---------------- 4. PANTALLA AZUL ---------------- */
T("pantalla_azul", [
  "pantalla azul","blue screen","bsod","se reinicia solo","error azul","pantallazo azul","kernel"
], "Pantalla azul o reinicio inesperado", {
  acuse: "Tranquilo, esto no significa que la computadora esté rota. Es la forma que tiene de avisar que algo falló.",
  preguntas: ["¿Aparece un código o una palabra rara al final del mensaje?", "¿Pasa siempre o solo de vez en cuando?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Anota o fotografía el código que aparece abajo de la carita triste.", d:"Códigos como 0x0000007E o MEMORY_MANAGEMENT nos dicen la causa."},
      {t:"Si la computadora arranca normal, revisa que no haya actualizaciones pendientes.", d:"Configuración → Windows Update. Muchos errores azules se corrigen con parches."},
      {t:"Actualiza los controladores de video.", d:"Administrador de dispositivos → Adaptadores de pantalla → clic derecho → Actualizar controlador."},
      {t:"Desconecta dispositivos conectados por USB que agregaste recientemente.", d:"Un pendrive o un disco externo en mal estado puede causar el error."},
      {t:"Revisa la memoria RAM con la Herramienta de diagnóstico de memoria de Windows.", d:"Busca 'diagnóstico de memoria' en el menú Inicio y sigue las instrucciones. Tarda unos minutos."},
      {t:"Si la computadora no arranca bien, entra en Modo seguro.", d:"Enciende y aprieta F8 repetidamente, o mantén Shift mientras eliges Reiniciar."},
      {t:"Si los errores son frecuentes, puede ser falla de disco o de memoria.", d:"Eso necesita revisión técnica; guarda tus archivos en un pendrive por precaución."}
    ],
    apple: [
      {t:"Anota el mensaje que aparece antes de reiniciarse.", d:"Si puedes, toma una foto con el celular."},
      {t:"Reinicia la Mac; si vuelve a pasar, apaga y enciende en modo seguro.", d:"Aprieta Shift al encender hasta ver el logo. El modo seguro desactiva programas de inicio."},
      {t:"Actualiza el sistema: menú Apple → Ajustes del Sistema → General → Actualización de software.", d:"Apple incluye correcciones en cada actualización."},
      {t:"Desconecta accesorios que agregaste recientemente.", d:"Un adaptador o disco externo con falla puede causar reinicios."},
      {t:"Verifica el disco con Utilidad de Discos → botón 'SOS' o 'Primeros auxilios'.", d:"Si reporta errores que no se pueden reparar, respalda ya mismo."},
      {t:"Si pasa seguido, guarda respaldo y consulta con el servicio técnico autorizado.", d:"Puede ser un problema de hardware que necesita diagnóstico especializado."}
    ],
    linux: [
      {t:"Al reiniciarse, revisa los mensajes con 'journalctl -xb -p 3'.", d:"Ahí aparecen los errores críticos que causaron el fallo."},
      {t:"Revisa la temperatura y la memoria con 'free -h' y 'sensors'.", d:"Si la memoria está llena o la temperatura es muy alta, eso causa bloqueos."},
      {t:"Verifica el disco con 'sudo smartctl -a /dev/sda' si está instalado.", d:"Muestra si el disco está empezando a fallar."},
      {t:"Actualiza el kernel y los controladores si es posible.", d:"Con tu gestor de paquetes habitual."},
      {t:"Revisa los logs del sistema después del reinicio.", d:"Los mensajes suelen indicar el módulo o el driver que falló."}
    ]
  }
});

/* ---------------- 5. PANTALLA NEGRA ---------------- */
T("pantalla_negra", [
  "pantalla negra","pantalla en negro","pantalla esta negra","no da imagen","monitor negro","se apaga la pantalla","black screen","no se ve nada","la pantalla no se ve","se quedo en negro"
], "Pantalla en negro", {
  acuse: "Vamos a distinguir si la computadora está encendida y solo es la imagen, o si está apagada de verdad.",
  preguntas: ["¿Se escuchan los ventiladores o se ve alguna luz encendida en la torre?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Mueve el mouse o aprieta una tecla.", d:"Puede ser que la pantalla solo se haya apagado por ahorro de energía."},
      {t:"Revisa que el monitor esté encendido y en la entrada correcta (HDMI, VGA, DisplayPort).", d:"El botón de entrada del monitor a veces cambia solo."},
      {t:"Mueve el mouse a ciegas y aprieta Enter, o prueba Ctrl + Alt + Supr.", d:"Si aparece la pantalla de bloqueo, la computadora funciona y era solo la imagen."},
      {t:"Si es laptop, sube el brillo con las teclas de función.", d:"Busca el dibujo del sol en las teclas F."},
      {t:"Reinicia con el botón de encendido mantenido 10 segundos.", d:"Después de apagar del todo, enciende normal."},
      {t:"Si el monitor dice 'sin señal', revisa el cable de video.", d:"Prueba con otro cable o con otra entrada del monitor."}
    ],
    apple: [
      {t:"Aprieta una tecla o mueve el trackpad.", d:"Puede ser solo el ahorro de energía."},
      {t:"Sube el brillo con las teclas de brillo.", d:"En MacBook, están en la fila superior."},
      {t:"Mantén el botón de encendido 10 segundos y vuelve a encender.", d:"Si arranca, era un bloqueo temporal."},
      {t:"Si es Mac de escritorio, revisa el cable del monitor y el conector de corriente.", d:"Prueba otra entrada de video si el monitor lo permite."},
      {t:"Si nada funciona, prueba con otra pantalla si puedes.", d:"Eso permite saber si el problema es la Mac o el monitor."}
    ],
    linux: [
      {t:"Prueba cambiar de consola con Ctrl + Alt + F2 (o F3, F4).", d:"Si aparece texto, el sistema está vivo y el problema es gráfico."},
      {t:"Mueve el mouse y prueba Ctrl + Alt + Supr para reiniciar.", d:"En muchos entornos gráficos eso reinicia la sesión."},
      {t:"Si conoces la terminal, revisa el estado gráfico con 'systemctl status display-manager'.", d:"Ahí verás si el servidor gráfico falló."},
      {t:"Reinicia el equipo desde el botón de encendido mantenido 10 segundos.", d:"Como último recurso antes de revisar hardware."},
      {t:"Revisa el cable y la entrada del monitor, igual que en cualquier sistema.", d:"Prueba con otro cable o pantalla para descartar."}
    ]
  }
});

/* ---------------- 6. SONIDO ---------------- */
T("sonido", [
  "sonido","audio","no se escucha","sin audio","no suena","altavoz","parlante","auriculares","mute"
], "No se escucha el sonido", {
  acuse: "Casi siempre es algo sencillo: el volumen, el dispositivo equivocado o un cable suelto.",
  preguntas: ["¿Usás parlantes externos, auriculares o el sonido de la laptop?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Mira el icono de la bocina, junto al reloj, y súbele el volumen.", d:"Asegúrate de que no tenga una línea roja o una x que indique silencio."},
      {t:"Clic derecho en la bocina → Abrir configuración de sonido.", d:"Revisa que el dispositivo de salida sea el correcto (parlantes o auriculares)."},
      {t:"Prueba reproducir algo y verifica que la barra de volumen se mueva.", d:"Si se mueve pero no suena, el problema es el parlante o el cable."},
      {t:"Revisa los cables de los parlantes y que estén enchufados en la salida verde.", d:"También revisa que los parlantes tengan corriente."},
      {t:"Actualiza el controlador de audio.", d:"Administrador de dispositivos → Controladoras de sonido → clic derecho → Actualizar."},
      {t:"Si el problema empezó después de una actualización, prueba restaurar el controlador anterior.", d:"En el mismo menú, elige 'Propiedades' → 'Revertir controlador'."}
    ],
    apple: [
      {t:"Revisa el icono de sonido en la barra superior.", d:"Asegúrate de que no esté silenciado y sube el volumen."},
      {t:"Abre Ajustes del Sistema → Sonido y revisa la salida seleccionada.", d:"Debe estar en los parlantes o en los auriculares, según lo que uses."},
      {t:"Desconecta y vuelve a conectar los auriculares.", d:"La Mac a veces no cambia sola de salida."},
      {t:"Reinicia la Mac.", d:"Un reinicio restablece el sistema de audio."},
      {t:"Si es un monitor externo, revisa que tenga parlantes y que esté elegido como salida.", d:"No todos los monitores traen audio."}
    ],
    linux: [
      {t:"Revisa el volumen y el silencio con el icono de sonido.", d:"Abre el mezclador y mira si la salida está silenciada."},
      {t:"Abre el control de audio (pavucontrol si está disponible).", d:"Ahí puedes ver y cambiar el dispositivo de salida."},
      {t:"Verifica que el servicio de audio esté funcionando.", d:"Con 'systemctl --user status pipewire' o 'pulseaudio' según tu sistema."},
      {t:"Reinicia el servicio de audio o el equipo.", d:"Muchas veces se resuelve con un reinicio simple."},
      {t:"Revisa los cables y el dispositivo físico.", d:"Prueba con auriculares para saber si el problema es de salida."}
    ]
  }
});

/* ---------------- 7. IMPRESORA ---------------- */
T("impresora", [
  "impresora","no imprime","imprimir","printer","no aparece la impresora","papel","escanea"
], "La impresora no imprime", {
  acuse: "Vamos a revisar de lo más simple a lo más técnico.",
  preguntas: ["¿La impresora está encendida y conectada por cable o por wifi?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Revisa que la impresora esté encendida y con papel y tinta.", d:"A veces solo falta papel o está en pausa."},
      {t:"Abre Configuración → Bluetooth y dispositivos → Impresoras y escáneres.", d:"Ahí ves si aparece y si está en línea."},
      {t:"Si dice 'sin conexión', clic en ella y elige 'Abrir cola'.", d:"Borra los trabajos atascados con clic derecho → Cancelar."},
      {t:"Reinicia la computadora y la impresora.", d:"Apaga la impresora, espera 30 segundos y enciéndela."},
      {t:"Si es wifi, revisa que la impresora esté en la misma red.", d:"Imprime la página de configuración de red desde el menú de la impresora."},
      {t:"Reinstala el controlador desde la página oficial del fabricante.", d:"HP, Canon, Epson, Brother y Lexmark tienen descargas oficiales por modelo."}
    ],
    apple: [
      {t:"Revisa que la impresora esté encendida y con papel.", d:"Lo primero siempre es lo físico."},
      {t:"Abre Ajustes del Sistema → Impresoras y escáneres.", d:"Verifica que aparezca y que esté seleccionada."},
      {t:"Borra los trabajos de impresión atascados.", d:"Haz clic en la impresora y usa el botón de abrir cola para cancelar."},
      {t:"Apaga y enciende la impresora, y reinicia la Mac.", d:"Eso reconecta el servicio de impresión."},
      {t:"Si es inalámbrica, revisa que esté en la misma red wifi.", d:"Los ajustes suelen estar en la pantalla de la impresora."}
    ],
    linux: [
      {t:"Revisa que la impresora esté encendida y conectada.", d:"Por USB o por red."},
      {t:"Abre la configuración de impresoras del sistema.", d:"En GNOME: Configuración → Impresoras."},
      {t:"Revisa la cola de impresión y cancela los trabajos atascados.", d:"Usa 'cancel -a' o la interfaz gráfica."},
      {t:"Reinicia el servicio de impresión: 'sudo systemctl restart cups'.", d:"Cups es el sistema de impresión estándar."},
      {t:"Instala el controlador correspondiente desde el repositorio de tu distribución.", d:"Muchas impresoras funcionan sin controlador adicional."}
    ]
  }
});

/* ---------------- 8. ACTUALIZACIÓN TRABADA ---------------- */
T("actualizacion", [
  "actualizacion","actualizando","update","no avanza","se quedo en","porcentaje","configurando","upgrade"
], "La actualización no avanza", {
  acuse: "Es una de las cosas que más asusta, pero casi siempre se resuelve esperando o reiniciando con cuidado.",
  preguntas: ["¿Hace cuánto tiempo está en la misma pantalla o el mismo porcentaje?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Espera al menos 30 minutos si el disco es viejo.", d:"Las actualizaciones grandes pueden tardar bastante. No lo apagues al minuto."},
      {t:"Revisa que el cable de corriente esté conectado.", d:"Si se apaga por falta de batería, puede quedar dañado."},
      {t:"Si lleva más de una hora igual, mantén apretado el botón de encendido 10 segundos.", d:"Al reiniciar, Windows intentará deshacer o completar la actualización."},
      {t:"Si vuelve a quedar trabada, enciende en Modo seguro.", d:"Mantén Shift al elegir Reiniciar."},
      {t:"En Modo seguro, desinstala la última actualización.", d:"Configuración → Windows Update → Historial → Desinstalar actualizaciones."},
      {t:"Pausa las actualizaciones automáticas por un tiempo si el problema se repite.", d:"Configuración → Windows Update → Pausar actualizaciones."}
    ],
    apple: [
      {t:"Espera; las actualizaciones grandes pueden tardar más de una hora.", d:"La barra a veces se queda quieta sin estar trabada."},
      {t:"Revisa que el cargador esté conectado.", d:"Una Mac sin corriente no completa la actualización."},
      {t:"Si lleva mucho tiempo, mantén el botón de encendido 10 segundos.", d:"Al volver a encender, macOS retoma o repara el proceso."},
      {t:"Si arranca en modo recuperación, usa la opción de reinstalar macOS conservando tus datos.", d:"Esa opción no borra archivos personales."},
      {t:"Si no puedes entrar, contacta con el soporte de Apple.", d:"Ellos guían el proceso paso a paso."}
    ],
    linux: [
      {t:"Espera un rato; las actualizaciones grandes pueden tardar.", d:"No cierres la terminal ni apagues el equipo."},
      {t:"Revisa que haya espacio libre ('df -h').", d:"Sin espacio, la actualización se queda congelada."},
      {t:"Si la terminal está trabada, aprieta Ctrl + C para cancelar.", d:"Después vuelve a ejecutar la actualización."},
      {t:"Reinicia el equipo si no responde.", d:"Puede quedar una actualización pendiente; vuelve a lanzarla."},
      {t:"Si el sistema no arranca, entra en modo recuperación desde el menú de arranque.", d:"Ahí puedes reparar paquetes o hacer una actualización desde consola."}
    ]
  }
});

/* ---------------- 9. CONTRASEÑA ---------------- */
T("contrasena", [
  "contraseña","contrasena","password","olvide mi contraseña","olvide la contraseña","clave","pin","usuario de windows","contraseña de windows","contraseña de la mac"
], "Olvidé la contraseña de mi usuario", {
  acuse: "Vamos a recuperarla sin perder tus archivos. Si el equipo es de una empresa o escuela, hay que avisar al administrador.",
  preguntas: ["¿El equipo es tuyo personal o de una empresa/escuela?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Si iniciaste sesión con una cuenta de Microsoft, usa el botón 'Olvidé mi contraseña' en la pantalla de inicio.", d:"Te enviarán un código al correo o al teléfono de recuperación."},
      {t:"Si es cuenta local y tienes otro usuario administrador, entra con ese y restablece la contraseña.", d:"Configuración → Cuentas → Familia y otros usuarios."},
      {t:"Si nadie más puede entrar, usa las preguntas de seguridad si las configuraste.", d:"Aparecen debajo del campo de contraseña."},
      {t:"Como último recurso, se puede reinstalar el sistema, pero borra archivos.", d:"Antes de eso, intenta sacar los datos arrancando desde un USB con Linux."},
      {t:"Si es un equipo de trabajo, no intentes forzar nada: pide ayuda al área de sistemas.", d:"Así te ahorras problemas con la empresa."}
    ],
    apple: [
      {t:"En la pantalla de inicio, espera y aparecerá la opción de recuperar la cuenta.", d:"Puedes usar tu Apple ID o la contraseña de la Mac."},
      {t:"Si tienes un Apple ID vinculado, elige 'Restablecer con Apple ID'.", d:"Te enviarán un código de verificación."},
      {t:"Si no, usa la opción de reiniciar la contraseña desde el menú de recuperación.", d:"Apaga y enciende manteniendo Cmd + R; ahí hay una utilidad de contraseñas."},
      {t:"Si tienes FileVault activo, necesitarás la clave de recuperación.", d:"Busca en tu cuenta iCloud o en el papel donde la guardaste."},
      {t:"En Mac de empresa, contacta al administrador.", d:"Ellos pueden restablecerla de forma segura."}
    ],
    linux: [
      {t:"Si tienes otro usuario con permisos de administrador, entra con él.", d:"Desde ahí puedes cambiar la contraseña del otro usuario."},
      {t:"Como administrador, usa 'sudo passwd nombre_usuario'.", d:"Te pedirá escribir la nueva contraseña dos veces."},
      {t:"Si no puedes entrar, arranca en modo recuperación desde el menú de arranque.", d:"Suele ser la opción 'Recovery mode'."},
      {t:"En la consola de recuperación, monta el disco y cambia la contraseña con 'passwd'.", d:"Requiere cierta práctica; pide ayuda si no te sientes cómodo."},
      {t:"Si los datos son importantes, respáldalos antes desde un USB de arranque.", d:"Así no arriesgas nada."}
    ]
  }
});

/* ---------------- 10. VIRUS ---------------- */
T("virus", [
  "virus","malware","ventanas raras","publicidad","pop ups","se abre solo","hackeado","ransomware"
], "Posible virus o ventanas raras", {
  acuse: "Buena noticia: la mayoría de estas cosas se pueden quitar sin formatear. Primero, calma y no hagas clic en nada raro.",
  preguntas: ["¿Aparecen ventanas solas o tu navegador te manda a páginas extrañas?"],
  peligro: true,
  pasos: {
    windows: [
      {t:"No hagas clic en las ventanas emergentes. Ciérralas con la X, no con los botones de adentro.", d:"Algunos botones falsos dicen 'descargar' o 'cerrar' y en realidad instalan algo."},
      {t:"Ejecuta un análisis completo con Seguridad de Windows (Windows Defender).", d:"Busca 'Seguridad de Windows' → Protección antivirus → Opciones de análisis → Análisis completo."},
      {t:"Revisa los programas instalados y desinstala lo que no reconozcas.", d:"Configuración → Aplicaciones. Anota los nombres raros antes de desinstalar."},
      {t:"Quita extensiones del navegador que no recuerdes haber agregado.", d:"En Chrome: menú → Extensiones. En Edge: menú → Extensiones."},
      {t:"Cambia la contraseña de tu correo y de tus cuentas importantes desde otro dispositivo.", d:"Esto es clave si sospechas que alguien entró a tus cuentas."},
      {t:"Si aparece un mensaje pidiendo dinero para desbloquear archivos, apaga el equipo y pide ayuda.", d:"Eso es ransomware y mientras menos lo uses, mejor."}
    ],
    apple: [
      {t:"Cierra las ventanas extrañas sin hacer clic en sus botones.", d:"Usa Cmd + Q o el botón de cerrar ventana."},
      {t:"Revisa las extensiones de Safari (Ajustes → Extensiones) y de Chrome.", d:"Quita las que no reconozcas."},
      {t:"Revisa Ajustes del Sistema → General → Ítems de inicio y quita lo sospechoso.", d:"Los programas raros suelen abrir junto al sistema."},
      {t:"Actualiza macOS y reinicia.", d:"Las actualizaciones cierran vulnerabilidades."},
      {t:"Si instalaste una app pirata o de fuente dudosa, desinstálala ya.", d:"Muchos problemas empiezan ahí."}
    ],
    linux: [
      {t:"Revisa los procesos que más consumen y los que no reconoces.", d:"Con 'top' o 'htop'."},
      {t:"Revisa el arranque automático y los servicios activos.", d:"Busca servicios desconocidos con 'systemctl list-unit-files --state=enabled'."},
      {t:"Actualiza el sistema y los paquetes.", d:"Las actualizaciones tapan fallas de seguridad."},
      {t:"Revisa las extensiones del navegador.", d:"Elimina las que no uses."},
      {t:"Si sospechas compromiso, cambia las contraseñas de tus cuentas desde otro equipo.", d:"Hazlo también con las claves de acceso remoto (sudo, SSH)."}
    ]
  }
});

/* ---------------- 11. DISCO LLENO ---------------- */
T("disco_lleno", [
  "disco lleno","sin espacio","no hay espacio","lleno","almacenamiento","disk full","memoria llena"
], "El disco está lleno", {
  acuse: "Vamos a liberar espacio sin borrar nada importante.",
  preguntas: ["¿Qué mensaje exacto aparece cuando dice que no hay espacio?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Abre Configuración → Sistema → Almacenamiento.", d:"Ahí ves qué ocupa el espacio: aplicaciones, fotos, documentos, temporal."},
      {t:"Vacía la Papelera de reciclaje.", d:"Clic derecho en el icono → Vaciar papelera."},
      {t:"Borra los archivos temporales con el Liberador de espacio.", d:"Busca 'Liberador de espacio' en el menú Inicio."},
      {t:"Mueve fotos y videos a un disco externo o a la nube.", d:"Suelen ser lo que más pesa."},
      {t:"Desinstala programas que no uses.", d:"Sobre todo juegos grandes y programas de prueba."},
      {t:"Activa la 'Sensor de almacenamiento' si quieres que se limpie solo.", d:"Está en la misma pantalla de Almacenamiento."}
    ],
    apple: [
      {t:"Abre menú Apple → Ajustes del Sistema → General → Almacenamiento.", d:"Te muestra qué ocupa el disco con colores."},
      {t:"Vacía la Papelera.", d:"Clic derecho en el icono del Dock → Vaciar papelera."},
      {t:"Revisa Descargas y borra lo que no necesites.", d:"Suele acumular instaladores viejos."},
      {t:"Mueve fotos y videos grandes a iCloud o a un disco externo.", d:"Puedes activar 'Optimizar almacenamiento' en Fotos."},
      {t:"Revisa las copias de seguridad locales y las versiones antiguas.", d:"En el mismo panel de Almacenamiento hay recomendaciones automáticas."}
    ],
    linux: [
      {t:"Revisa el espacio con 'df -h'.", d:"Así ves qué partición está llena."},
      {t:"Busca los archivos más grandes con 'du -h /home | sort -hr | head -20'.", d:"Empieza por la carpeta personal."},
      {t:"Limpia la caché de paquetes con 'sudo apt clean'.", d:"Los paquetes descargados ya no hacen falta."},
      {t:"Borra registros antiguos con 'sudo journalctl --vacuum-size=200M'.", d:"Puede liberar cientos de MB."},
      {t:"Revisa Descargas y la Papelera.", d:"También se acumula."}
    ]
  }
});

/* ---------------- 12. CALOR / RUIDO ---------------- */
T("calor", [
  "calor","se calienta","ruido","ventilador","se apaga solo","temperatura","sobrecalentamiento","hace ruido"
], "Se calienta mucho o hace ruido", {
  acuse: "Esto puede afectar la vida de la computadora, así que conviene atenderlo.",
  preguntas: ["¿Hace ruido fuerte el ventilador y se calienta incluso con poco trabajo?"],
  peligro: true,
  pasos: {
    windows: [
      {t:"Revisa que las rejillas de ventilación estén libres.", d:"No la uses sobre la cama o el sofá: tapan la salida de aire."},
      {t:"Limpia el polvo de las rejillas con aire comprimido.", d:"Con la computadora apagada y desenchufada."},
      {t:"Usa la computadora sobre una superficie dura y plana.", d:"Una base con patas o un soporte ayuda mucho."},
      {t:"Revisa qué programa está usando mucho procesador.", d:"Ctrl + Shift + Esc y ordena por CPU."},
      {t:"Revisa la temperatura si puedes.", d:"Programas como HWMonitor muestran los grados. Arriba de 90 °C es preocupante."},
      {t:"Si el ruido es un golpeteo, puede ser el disco o un ventilador dañado.", d:"Conviene revisión técnica antes de que falle del todo."}
    ],
    apple: [
      {t:"Usa la Mac sobre una superficie dura, sin almohadas ni mantas.", d:"Las MacBooks se enfrían por la base y el teclado."},
      {t:"Cierra apps que usen mucho procesador.", d:"Monitor de Actividad → ordenar por CPU."},
      {t:"Reinicia la Mac y observa si el ruido continúa.", d:"A veces es una app atascada."},
      {t:"No la uses en la cama; el ventilador se tapa.", d:"Y se calienta más."},
      {t:"Si el ventilador suena fuerte y la Mac se apaga sola, pide revisión técnica.", d:"Puede estar sucio por dentro o tener un sensor con falla."}
    ],
    linux: [
      {t:"Revisa la temperatura con 'sensors'.", d:"Si no lo tienes, instala 'lm-sensors'."},
      {t:"Revisa qué procesos consumen CPU con 'top' o 'htop'.", d:"Un proceso al 100% calienta el equipo."},
      {t:"Revisa la limpieza física del ventilador.", d:"Con el equipo apagado."},
      {t:"Ajusta el perfil de energía a 'equilibrado' si tienes uno agresivo.", d:"En algunos portátiles hay perfiles de rendimiento."},
      {t:"Si el equipo se apaga solo, revisa los registros de temperatura.", d:"Puede ser un apagado de protección."}
    ]
  }
});

/* ---------------- 13. USB ---------------- */
T("usb", [
  "usb","pendrive","memoria usb","no reconoce","disco externo","no aparece la usb","no lee la memoria"
], "No reconoce la memoria USB", {
  acuse: "Vamos a probar si el problema es la memoria o la computadora.",
  preguntas: ["¿La memoria funciona en otra computadora?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Prueba la memoria en otro puerto USB.", d:"Sobre todo en uno que esté directo en la computadora, no en un hub."},
      {t:"Prueba en otra computadora.", d:"Si ahí funciona, el problema es el puerto; si no, la memoria."},
      {t:"Abre el Administrador de discos: clic derecho en Inicio → Administración de discos.", d:"Ahí ves si aparece con letra o sin formato."},
      {t:"Si aparece sin letra, asígnale una: clic derecho → Cambiar letra de unidad.", d:"No elijas 'Formatear' si tiene datos que necesitas."},
      {t:"Revisa si aparece un aviso de error al conectarla.", d:"Anota el mensaje para buscar la causa."}
    ],
    apple: [
      {t:"Prueba en otro puerto o con otro adaptador.", d:"Los adaptadores USB-C a veces fallan."},
      {t:"Abre Utilidad de Discos y revisa si aparece.", d:"Aplicaciones → Utilidades → Utilidad de Discos."},
      {t:"Si aparece pero no se monta, prueba 'Montar' con el botón.", d:"Si el disco está dañado, puede mostrar error."},
      {t:"Prueba en otra computadora para descartar.", d:"Si no funciona en ninguna, la memoria puede estar dañada."},
      {t:"Si tiene datos importantes, no la formatees; consulta a un técnico en recuperación.", d:"Formatear borra posibilidades de recuperación."}
    ],
    linux: [
      {t:"Revisa si el sistema la detecta con 'lsblk'.", d:"Aparece como sdb o sdc, con sus particiones."},
      {t:"Revisa el registro del sistema al conectarla con 'dmesg | tail -20'.", d:"Ahí se ve si hubo un error de lectura."},
      {t:"Si aparece pero no se monta, móntala manualmente con 'sudo mount /dev/sdX1 /mnt'.", d:"Cambia sdX1 por el nombre real que viste en lsblk."},
      {t:"Prueba en otro puerto y en otro equipo.", d:"Así descartas el puerto."},
      {t:"Si el disco tiene datos importantes, no lo formatees.", d:"Pide ayuda a alguien con experiencia en recuperación."}
    ]
  }
});

/* ---------------- 14. BATERÍA ---------------- */
T("bateria", [
  "bateria","batería","no carga","no dura","cargador","battery","se descarga rapido"
], "La batería no dura o no carga", {
  acuse: "Vamos a revisar el cargador, el consumo y la salud de la batería.",
  preguntas: ["¿El cargador calienta o hace ruido?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Revisa el cable y el conector del cargador.", d:"Prueba con otro cargador compatible si puedes."},
      {t:"Revisa la salud de la batería con el informe de energía.", d:"Abre CMD como administrador y ejecuta: powercfg /batteryreport. Te genera un archivo HTML con los datos."},
      {t:"Baja el brillo y cierra apps en segundo plano.", d:"El brillo alto consume mucho."},
      {t:"Revisa el modo de energía: Configuración → Sistema → Energía y batería.", d:"Elige un modo equilibrado o de ahorro."},
      {t:"Si la batería tiene más de 4 o 5 años y dura muy poco, ya cumplió su vida útil.", d:"Cambiarla suele ser la solución."}
    ],
    apple: [
      {t:"Revisa el cargador y el cable, y prueba otro.", d:"Los cables se dañan con el uso."},
      {t:"Revisa el estado de la batería: menú Apple → Ajustes del Sistema → Batería.", d:"Muestra si necesita servicio."},
      {t:"Baja el brillo y cierra apps pesadas.", d:"Ayuda bastante."},
      {t:"Revisa las apps que más energía consumen en el panel de Batería.", d:"Ahí aparece el consumo por app."},
      {t:"Si dice 'Servicio recomendado', es momento de cambiarla en un servicio autorizado.", d:"No la cambies por una genérica si puedes evitarlo."}
    ],
    linux: [
      {t:"Revisa el estado con 'upower -i /org/freedesktop/UPower/devices/battery_BAT0'.", d:"Muestra capacidad, estado y salud."},
      {t:"Revisa qué consume más energía con 'powertop' si está disponible.", d:"Requiere instalarlo."},
      {t:"Baja el brillo y revisa el perfil de energía.", d:"Algunas distribuciones tienen perfiles de ahorro."},
      {t:"Prueba con otro cargador compatible.", d:"Descarta el cargador primero."},
      {t:"Si la salud de la batería es baja, cámbiala.", d:"Con los años pierden capacidad."}
    ]
  }
});

/* ---------------- 15. MICRÓFONO / CÁMARA ---------------- */
T("microfono", [
  "microfono","micrófono","no me escuchan","no se oye mi voz","camara","cámara","videollamada","zoom","meet","teams"
], "El micrófono o la cámara no funcionan", {
  acuse: "Esto se revisa en tres lugares: el aparato, la aplicación y los permisos del sistema.",
  preguntas: ["¿Pasa en todas las aplicaciones o solo en una?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Revisa que el micrófono o la cámara no tengan un interruptor de silencio.", d:"Algunos traen un botón físico o una tapita."},
      {t:"Revisa los permisos: Configuración → Privacidad y seguridad → Micrófono / Cámara.", d:"Activa el acceso para las aplicaciones que lo necesiten."},
      {t:"Revisa el dispositivo de entrada: Configuración → Sistema → Sonido.", d:"Elige el micrófono correcto."},
      {t:"Dentro de la aplicación (Zoom, Meet, Teams), revisa su configuración de audio y video.", d:"Suele estar en el menú de ajustes de la app."},
      {t:"Cierra otras apps que puedan estar usando la cámara.", d:"Solo una aplicación puede usarla a la vez en muchos casos."},
      {t:"Prueba el dispositivo en otra computadora si puedes.", d:"Para saber si es el aparato o la configuración."}
    ],
    apple: [
      {t:"Revisa Ajustes del Sistema → Privacidad y seguridad → Micrófono / Cámara.", d:"Activa las apps que lo necesiten."},
      {t:"Revisa la configuración de la aplicación (Zoom, Meet, FaceTime).", d:"Elige el dispositivo correcto."},
      {t:"Revisa Ajustes del Sistema → Sonido → Entrada.", d:"Ahí ves si el micrófono detecta sonido (la barra se mueve)."},
      {t:"Reinicia la Mac.", d:"A veces el acceso se queda trabado."},
      {t:"Cierra otras apps que estén usando la cámara.", d:"Solo una puede usarla."}
    ],
    linux: [
      {t:"Revisa los dispositivos disponibles con 'arecord -l'.", d:"Muestra los micrófonos detectados."},
      {t:"Revisa si están silenciados en el mezclador de audio.", d:"Con pavucontrol o alsamixer."},
      {t:"Revisa si el usuario pertenece al grupo de audio.", d:"Con 'groups' en la terminal."},
      {t:"Revisa la configuración de la aplicación.", d:"Elige el dispositivo de entrada y salida."},
      {t:"Prueba con otra aplicación para descartar.", d:"Si funciona en otra, el problema es de la app."}
    ]
  }
});

/* ---------------- 16. CORREO ---------------- */
T("correo", [
  "correo","email","gmail","outlook","no puedo entrar al correo","no puedo entrar a mi correo","entrar al correo","entrar a mi correo","cuenta bloqueada","no me llega","contraseña correo","cuenta de correo","bandeja de entrada"
], "No puedo entrar a mi correo", {
  acuse: "Vamos a revisar si es la contraseña, la conexión o la seguridad de la cuenta.",
  preguntas: ["¿Aparece algún mensaje cuando intentas entrar?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Revisa que tu conexión a internet funcione; abre otra página.", d:"Si no navega, el problema no es el correo."},
      {t:"Escribe la contraseña de nuevo con cuidado, revisando mayúsculas.", d:"O usa el botón de ver contraseña para revisarla."},
      {t:"Si dice 'contraseña incorrecta', usa 'Olvidé mi contraseña'.", d:"Te enviarán un código o un enlace de recuperación."},
      {t:"Revisa la carpeta de spam de tu correo de respaldo.", d:"A veces el código de recuperación cae ahí."},
      {t:"Si dice que la cuenta está bloqueada, espera unas horas o sigue el proceso de verificación.", d:"Las cuentas se bloquean por intentos fallidos."},
      {t:"Si te llegó un aviso de inicio de sesión desconocido, cambia la contraseña ya.", d:"Y activa la verificación en dos pasos."}
    ],
    apple: [
      {t:"Revisa que tengas internet.", d:"Prueba abrir otra página."},
      {t:"Revisa la contraseña y las mayúsculas.", d:"El teclado a veces está con mayúsculas sin que lo notes."},
      {t:"Usa la opción 'Olvidé mi contraseña' en el sitio del correo.", d:"Te guiará para restablecerla."},
      {t:"Revisa si el correo está en la app Mail o en el navegador.", d:"Puede ser un problema solo de la app."},
      {t:"Si es de trabajo o escuela, avisa al administrador.", d:"Ellos tienen que desbloquear la cuenta."}
    ],
    linux: [
      {t:"Revisa la conexión a internet.", d:"Con 'ping 8.8.8.8' o abriendo una página."},
      {t:"Revisa la contraseña y el servidor de correo configurado.", d:"En Thunderbird: Configuración de la cuenta."},
      {t:"Prueba entrar desde el navegador web del proveedor.", d:"Así sabes si el problema es la app o la cuenta."},
      {t:"Revisa los mensajes de error del cliente de correo.", d:"Suelen indicar si es autenticación o conexión."},
      {t:"Si usas verificación en dos pasos, necesitas la contraseña de aplicación.", d:"Muchos proveedores la exigen para clientes de correo."}
    ]
  }
});

/* ---------------- 17. ARCHIVO PERDIDO ---------------- */
T("archivo_perdido", [
  "borré un archivo","archivo perdido","recuperar archivo","papelera","se borro","recuperar foto","delete"
], "Borré un archivo sin querer", {
  acuse: "Mientras menos uses el equipo, más posibilidades hay de recuperarlo. Vamos rápido.",
  preguntas: ["¿Fue hace poco y todavía no reiniciaste la computadora?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Revisa la Papelera de reciclaje primero.", d:"Clic derecho → Restaurar si lo encuentras."},
      {t:"Si usas OneDrive, revisa la papelera de OneDrive.", d:"Entra a onedrive.com y busca la papelera."},
      {t:"Revisa el Historial de versiones: clic derecho en la carpeta → Propiedades → Versiones anteriores.", d:"Puede haber una copia."},
      {t:"Si no aparece, evita guardar archivos nuevos en ese disco.", d:"Cada archivo nuevo puede sobrescribir lo borrado."},
      {t:"Usa un programa de recuperación como Recuva o PhotoRec.", d:"Instálalo en otro disco si es posible."},
      {t:"Si es muy importante, no toques más el disco y consulta a un servicio de recuperación.", d:"Ellos tienen herramientas especiales."}
    ],
    apple: [
      {t:"Revisa la Papelera del Dock.", d:"Clic derecho → Poner de vuelta si está ahí."},
      {t:"Si usas iCloud Drive, revisa la sección de eliminados recientes.", d:"En iCloud.com → Archivos → Recientemente eliminados."},
      {t:"Usa Time Machine si lo tienes activado.", d:"Es la mejor forma de recuperar archivos en Mac."},
      {t:"Si el archivo estaba en una carpeta sincronizada, revisa el historial de versiones.", d:"En algunas apps hay versiones anteriores."},
      {t:"Si no aparece nada, consulta un especialista antes de seguir usando el disco.", d:"Así no se sobrescribe la información."}
    ],
    linux: [
      {t:"Revisa la papelera del escritorio.", d:"En la mayoría de entornos gráficos está en el escritorio."},
      {t:"Revisa el registro de shell si borraste desde la terminal.", d:"Solo te dice el comando, no recupera el archivo."},
      {t:"Deja de escribir en el disco afectado.", d:"Cuanto menos se use, mejor."},
      {t:"Usa 'photorec' o 'testdisk' para intentar la recuperación.", d:"Son herramientas de consola muy efectivas."},
      {t:"Si es crítico, consulta con un especialista.", d:"Sobre todo si es un disco con datos importantes."}
    ]
  }
});

/* ---------------- 18. TECLADO ---------------- */
T("teclado", [
  "teclado","teclas","no funciona una tecla","keyboard","no escribe","teclas locas","se escribe solo"
], "El teclado no funciona bien", {
  acuse: "Vamos a revisar si es el teclado o el sistema.",
  preguntas: ["¿Falla en todas las aplicaciones o solo en una?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Prueba el teclado en otra aplicación o en otra computadora.", d:"Así sabes si es el aparato."},
      {t:"Reinicia la computadora.", d:"Un bloqueo temporal se resuelve así."},
      {t:"Revisa las opciones de accesibilidad.", d:"Configuración → Accesibilidad → Teclado. Desactiva las 'Teclas de filtro' o 'Teclas especiales' si están activas."},
      {t:"Revisa el idioma del teclado.", d:"A veces cambia el idioma y no coinciden las teclas."},
      {t:"Si es un teclado externo, revisa el cable o el receptor inalámbrico.", d:"Prueba otro puerto o cambia las pilas."},
      {t:"Si la falla es física, reemplazar el teclado suele ser la mejor opción.", d:"En laptops lo hace un técnico."}
    ],
    apple: [
      {t:"Prueba el teclado en otra app.", d:"Si solo falla en una, es la app."},
      {t:"Reinicia la Mac.", d:"Resuelve bloqueos temporales."},
      {t:"Revisa Ajustes del Sistema → Accesibilidad → Teclado.", d:"Desactiva las teclas de filtro si están activas."},
      {t:"Revisa el idioma de entrada en la barra superior.", d:"A veces cambia sin darte cuenta."},
      {t:"Si es teclado externo, prueba otro puerto o cambia pilas.", d:"O prueba con otro cable."}
    ],
    linux: [
      {t:"Prueba el teclado en otra aplicación o en la terminal.", d:"Con 'xev' puedes ver si las teclas emiten eventos."},
      {t:"Revisa la configuración de distribución del teclado.", d:"Con 'setxkbmap -query'."},
      {t:"Reinicia el equipo.", d:"Un reinicio limpio suele resolverlo."},
      {t:"Si es externo, prueba otro puerto o el receptor inalámbrico.", d:"Cambia las pilas si es inalámbrico."},
      {t:"Si la falla es física, reemplaza el teclado.", d:"En laptops requiere servicio técnico."}
    ]
  }
});

/* ---------------- 19. WIFI SE CAE ---------------- */
T("wifi_cae", [
  "se cae el wifi","wifi inestable","se desconecta","internet lento","cortes","ping alto","se va el internet"
], "El wifi se desconecta solo", {
  acuse: "Vamos a revisar la distancia, las interferencias y el router.",
  preguntas: ["¿Pasa cerca del router o también lejos?"],
  peligro: false,
  pasos: {
    windows: [
      {t:"Acércate al router y prueba si mejora.", d:"Si mejora, el problema es la señal."},
      {t:"Reinicia el router, apagándolo 30 segundos.", d:"Es la solución más común."},
      {t:"Revisa la banda: 2.4 GHz llega más lejos; 5 GHz es más rápida pero de menor alcance.", d:"Si estás lejos, conecta a la de 2.4 GHz."},
      {t:"Aleja el router de microondas, teléfonos inalámbricos y paredes gruesas.", d:"Esos aparatos interfieren."},
      {t:"Actualiza el controlador del wifi.", d:"Administrador de dispositivos → Adaptadores de red."},
      {t:"Si hay muchas redes, cambia el canal del router.", d:"Se hace desde la configuración del router."}
    ],
    apple: [
      {t:"Acércate al router y prueba.", d:"La distancia afecta mucho."},
      {t:"Reinicia el router (30 segundos apagado).", d:"Resuelve la mayoría de los cortes."},
      {t:"Revisa si el problema es solo con tu Mac.", d:"Prueba con el celular en la misma zona."},
      {t:"Reinicia la Mac y revisa Ajustes de Red.", d:"A veces se queda con una configuración vieja."},
      {t:"Si solo falla la Mac, olvida la red y vuelve a conectarte.", d:"Ajustes → Red → Wifi → Detalles → Olvidar esta red."}
    ],
    linux: [
      {t:"Revisa la calidad de la señal.", d:"Con 'nmcli dev wifi' o el icono de red."},
      {t:"Reinicia el router.", d:"Desenchufar 30 segundos."},
      {t:"Revisa los logs de red para ver por qué se desconecta.", d:"Con 'journalctl -u NetworkManager'."},
      {t:"Aleja el equipo de fuentes de interferencia.", d:"Microondas, otros routers."},
      {t:"Si es un portátil con adaptador interno débil, considera uno USB.", d:"Suele mejorar bastante."}
    ]
  }
});

/* ---------------- Fallback ---------------- */
const FALLBACK = {
  acuse: "No tengo ese caso cargado exactamente, pero puedo ayudarte a diagnosticarlo con preguntas.",
  preguntas: ["¿Qué estaba haciendo cuando empezó el problema?","¿Aparece algún mensaje de error? Si es así, escríbelo tal cual."],
  peligro: false,
  pasos: {
    windows: [
      {t:"Anota el mensaje de error exacto, palabra por palabra.", d:"Es lo más útil para encontrar la causa."},
      {t:"Reinicia la computadora.", d:"Muchos problemas se van con un reinicio limpio."},
      {t:"Revisa si el problema empezó después de instalar algo o de una actualización.", d:"Si fue así, desinstalar puede resolverlo."},
      {t:"Si es un problema grave, guarda tus archivos en un pendrive.", d:"Así no pierdes nada mientras lo solucionamos."}
    ],
    apple: [
      {t:"Anota el mensaje exacto que aparece.", d:"Es lo primero para investigar."},
      {t:"Reinicia la Mac.", d:"Resuelve muchos bloqueos temporales."},
      {t:"Revisa si el problema apareció después de instalar una app o actualizar.", d:"Puedes desinstalar y probar."},
      {t:"Guarda una copia de tus archivos importantes.", d:"Nunca está de más."}
    ],
    linux: [
      {t:"Anota el mensaje de error exacto.", d:"En la terminal suele ser muy descriptivo."},
      {t:"Reinicia el equipo.", d:"Descarta fallas temporales."},
      {t:"Revisa los registros del sistema con 'journalctl -xb'.", d:"Ahí aparecen los errores del arranque."},
      {t:"Haz una copia de tus archivos importantes.", d:"Antes de cualquier cambio grande."}
    ]
  }
};

if (typeof module !== 'undefined') module.exports = { KB, EXAMPLES, FALLBACK };
